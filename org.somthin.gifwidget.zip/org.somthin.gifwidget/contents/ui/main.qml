import QtQuick 2.15
import org.kde.plasma.plasmoid 2.0

PlasmoidItem {
    width: 200
    height: 200

    AnimatedImage {
        id: gif
        source: Qt.resolvedUrl("../images/gif.gif")
        anchors.fill: parent
        fillMode: Image.PreserveAspectFit
        playing: true
        cache: true

        // Force garbage collection periodically
        Timer {
            interval: 30000 // Every 30 seconds
            running: true
            repeat: true
            onTriggered: gc()
        }
    }
}
